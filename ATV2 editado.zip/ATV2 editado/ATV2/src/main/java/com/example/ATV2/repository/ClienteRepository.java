package com.example.ATV2.repository;

import com.example.ATV2.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ClienteRepository extends JpaRepository <ClienteRepository, Long >{
    Optional<Usuario> findByEmail(String email);
}
